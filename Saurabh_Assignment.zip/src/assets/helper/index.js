const watchListData= new Array
export default watchListData;