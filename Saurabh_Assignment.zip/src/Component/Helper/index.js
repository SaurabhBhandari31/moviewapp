// I am using dummy data to show the functionalties puropse 



const LocationData = {

    "countries": [
        {
          "name": "USA",
          "states": [
            {
              "name": "California",
              "cities": [
                 {"name":"Los Angeles"},
                {"name":"San Francisco"},
                 {"name":"San Diego"}
              ]
            },
            {
              "name": "Texas",
              "cities": [
                {"name":"Houston"},
               {"name": "Austin"},
               {"name": "Dallas"}
              ]
            }
          ]
        },
        {
          "name": "Canada",
          "states": [
            {
              "name": "Ontario",
              "cities": [
                {"name":"Toronto"},
                {"name":"Ottawa"},
               { "name":"Hamilton"}
              ]
            },
            {
              "name": "Quebec",
              "cities": [
              { "name": "Montreal"},
               { "name":"Quebec City"},
                {"name":"Laval"}
              ]
            }
          ]
        },
        {
          "name": "Inida",
          "states": [
            {
              "name": "Uttarakhand",
              "cities": [
                 {"name":"Dehradun"},
                {"name":"Rishikesh"},
                 {"name":"Mussoorie"}
              ]
            },
            {
              "name": "Delhi",
              "cities": [
                {"name":"Noida"},
               {"name": "NCR"},
               {"name": "Delhi city"}
              ]
            }
          ]
        },
      ]
}


export default LocationData